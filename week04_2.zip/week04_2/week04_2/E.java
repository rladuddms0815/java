package week04_2;

public class E extends C {

}
