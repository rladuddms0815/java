package work04;

public interface Vehicle {
	void run();

}
