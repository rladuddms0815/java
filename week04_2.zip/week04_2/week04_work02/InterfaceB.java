package week04_work02;

public non-sealed interface InterfaceB extends InterfaceA {
	 void methodB();
	 }
