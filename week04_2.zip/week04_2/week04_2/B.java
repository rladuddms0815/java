package week04_2;

public class B implements A {

}
