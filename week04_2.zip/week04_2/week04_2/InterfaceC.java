package week04_2;

public interface InterfaceC extends InterfaceA, InterfaceB {

void methodC();
}
