package week04_2;

public interface Vehicle {
	void run();

}
