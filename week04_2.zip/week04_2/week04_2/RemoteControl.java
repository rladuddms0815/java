package week04_2;

public interface RemoteControl {
	void turnOn();
	void turnOff();

}
