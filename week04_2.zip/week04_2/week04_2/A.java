package week04_2;

public interface A {

}
