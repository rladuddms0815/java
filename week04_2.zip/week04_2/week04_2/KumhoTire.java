package week04_2;

public class KumhoTire implements Tire {
	public void roll() {
		System.out.println("금호타이어가굴러갑니다.");
		}
}
