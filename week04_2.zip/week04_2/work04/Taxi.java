package work04;

public class Taxi implements Vehicle {
	 
	 public void run() {
		 System.out.println("택시가달립니다.");
		 }
	 }

