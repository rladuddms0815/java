package week04_2;

public class C implements A {

}
