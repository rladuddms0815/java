package week04_2;

public interface Searchable {
	void search(String url);

}
