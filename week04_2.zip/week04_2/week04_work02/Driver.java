package week04_work02;

public class Driver {
	
	void drive(Vehicle vehicle) {
		vehicle.run();
	}

}
