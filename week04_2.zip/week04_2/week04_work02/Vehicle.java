package week04_work02;

public interface Vehicle {
	
	void run();

}
