package week04_work02;

public interface InterfaceC extends InterfaceB {
	 void methodC();
	 }
