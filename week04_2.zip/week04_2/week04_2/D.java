package week04_2;

public class D extends B {

}
