package week04_work02;

public sealed interface InterfaceA permits InterfaceB {
	 void methodA();
	 }
